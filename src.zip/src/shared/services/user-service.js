import axios from 'axios';

 class UserService {

  getUser() {
    //  const userPromise = axios.get('https://jsonplaceholder.typicode.com/users')
     const userPromise = axios.get(' https://demo1509725.mockable.io/product_details ')
    .then(res => res.data)
    return userPromise;
    
  }

}

export default UserService