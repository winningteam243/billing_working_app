import React, { Component } from 'react';
import './App.css'; 
import ControlledExpansionPanels from './components/abc/products'
// import User from './components/user/user'

class App extends Component {
  render() {
    return (
      <div className="container">
        {/* <User/> */}
        <ControlledExpansionPanels/>
      </div>
    );
  }
}

export default App;
